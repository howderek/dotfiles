# dotfiles
Local Install: 

    curl -fsS https://raw.githubusercontent.com/howderek/dotfiles/master/install.sh | bash


Remote Install: 

    ssh login@server.com 'set -s pipefail ; curl -fsShttps://raw.githubusercontent.com/howderek/dotfiles/master/install.sh | bash'
